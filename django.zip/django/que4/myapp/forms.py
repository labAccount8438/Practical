from django import forms
from .models import ProgrammingLanguage

class VoteForm(forms.ModelForm):
    class Meta:
        model = ProgrammingLanguage
        fields = ['name']
        labels = {
            'name': 'Number',  # Change the label for the 'name' field to 'Number'
        }