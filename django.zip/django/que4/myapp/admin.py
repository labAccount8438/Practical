from django.contrib import admin

from .models import ProgrammingLanguage, Vote

admin.site.register(ProgrammingLanguage)
admin.site.register(Vote)
