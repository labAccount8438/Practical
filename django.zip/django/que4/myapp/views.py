from django.shortcuts import render, redirect
from .models import ProgrammingLanguage, Vote
from .forms import VoteForm

def vote(request):
    if request.method == 'POST':
        form = VoteForm(request.POST)
        if form.is_valid():
            language_id = form.cleaned_data['name']
            programming_language = ProgrammingLanguage.objects.get(pk=language_id)
            Vote.objects.create(language=programming_language)
            return redirect('results')
    else:
        form = VoteForm()

    return render(request, 'myapp/vote.html', {'form': form})

def results(request):
    languages = ProgrammingLanguage.objects.all()
    return render(request, 'myapp/results.html', {'languages': languages})