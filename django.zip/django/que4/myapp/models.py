from django.db import models

class ProgrammingLanguage(models.Model):
    name = models.CharField(max_length=100)

class Vote(models.Model):
    language = models.ForeignKey(ProgrammingLanguage, on_delete=models.CASCADE)
